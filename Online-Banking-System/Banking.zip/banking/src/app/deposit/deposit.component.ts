import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';

import { Deposit } from '../deposit';
import { DepositService } from '../deposit.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  dep:Deposit = new Deposit();

  constructor(private depositeService: DepositService) { }

  ngOnInit(): void {

    
    
    
  }

 sweetalert(){
  Swal.fire(
    'Your money is deposit',
    '',
    'success'
  )
}
  Deposit(){
    console.log(this.dep);
    this.depositeService.deposit(this.dep).subscribe(data=>{
      alert("Successfully Deposite Your Amount")
    },error=>alert("Sorry your amount not deposite..."));
    

  }



}
