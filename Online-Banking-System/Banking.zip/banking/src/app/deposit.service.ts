import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Observer } from 'rxjs';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';
import { Deposit } from './deposit';

@Injectable({
  providedIn: 'root'
})
export class DepositService {
  baseUrl="http://localhost:8081/deposit"
  constructor(private httpClient: HttpClient) {}

  deposit(deposit: Deposit): Observable<object>{
    console.log(deposit);
    return this.httpClient.post('baseUrl',deposit);
    
  }
}
