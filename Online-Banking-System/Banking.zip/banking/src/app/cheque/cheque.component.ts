import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cheque',
  templateUrl: './cheque.component.html',
  styleUrls: ['./cheque.component.css']
})
export class ChequeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  sweetalert(){
    Swal.fire(
      'Your Cheque Book Request Sent',
      '',
      'success'
    )
}
}
