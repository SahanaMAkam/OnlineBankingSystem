import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NavbarComponent } from './navbar/navbar.component';
import { AccountComponent } from './account/account.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { ViewComponent } from './view/view.component';
import { RegisterComponent } from './register/register.component';
import { ProfileComponent } from './profile/profile.component';
import { ChequeComponent } from './cheque/cheque.component';
import { LoanComponent } from './loan/loan.component';
import { ViewsavingComponent } from './viewsaving/viewsaving.component';
import { HomeComponent } from './home/home.component';
import { AloginComponent } from './alogin/alogin.component';
import { UseraccountComponent } from './useraccount/useraccount.component';
import { ChequebookComponent } from './chequebook/chequebook.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:'Navbar',component:NavbarComponent},
  {path:'Account',component:AccountComponent},
  {path:'Deposit',component:DepositComponent},
  {path:'Withdraw',component:WithdrawComponent},
  {path:'View',component:ViewComponent},
  {path:'Register',component:RegisterComponent},
  {path:'Profile',component:ProfileComponent},
  {path:'Cheque',component:ChequeComponent},
  {path:'Loan',component:LoanComponent},
  {path:'Viewsaving',component:ViewsavingComponent},
  {path:'alogin',component:AloginComponent},
  {path:'useraccount',component:UseraccountComponent},
  {path:'chequebook',component:ChequebookComponent},
  {path:'Login',component:LoginComponent}

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
