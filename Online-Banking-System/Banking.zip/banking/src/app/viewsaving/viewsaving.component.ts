import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewsaving',
  templateUrl: './viewsaving.component.html',
  styleUrls: ['./viewsaving.component.css']
})
export class ViewsavingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
