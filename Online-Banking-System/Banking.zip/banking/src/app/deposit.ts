export class Deposit {
    account!:string;
    amount!:string;
    date!:string;
}
