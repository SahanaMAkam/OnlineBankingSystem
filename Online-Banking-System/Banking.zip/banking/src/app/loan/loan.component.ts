import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-loan',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.css']
})
export class LoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  sweetalert(){
    Swal.fire(
      'Your Loan Request Sent',
      '',
      'success'
    )
}
}
