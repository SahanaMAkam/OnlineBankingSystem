import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  sweetalert(){
    Swal.fire({
      title: 'You want to withdraw this Amount',
      showDenyButton: true,
      showCancelButton: true,
      confirmButtonText: 'Yes',
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('Withdraw Sucessfully', '', 'success')
      } else if (result.isDenied) {
        Swal.fire('Your withdraw amount Failed', '', 'info')
      }
    }
    )
}
}