import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chequebook',
  templateUrl: './chequebook.component.html',
  styleUrls: ['./chequebook.component.css']
})
export class ChequebookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
