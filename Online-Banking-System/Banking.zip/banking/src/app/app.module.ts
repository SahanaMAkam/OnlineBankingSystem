import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { AccountComponent } from './account/account.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { ViewComponent } from './view/view.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { ChequeComponent } from './cheque/cheque.component';
import { LoanComponent } from './loan/loan.component';
import { ViewsavingComponent } from './viewsaving/viewsaving.component';
import { HomeComponent } from './home/home.component';
import { AloginComponent } from './alogin/alogin.component';
import { UseraccountComponent } from './useraccount/useraccount.component';
import { ChequebookComponent } from './chequebook/chequebook.component';
import { LogoutComponent } from './logout/logout.component';
import { FormsModule } from '@angular/forms';

import{HttpClientModule} from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    AccountComponent,
    DepositComponent,
    WithdrawComponent,
    ViewComponent,
    RegisterComponent,
    LoginComponent,
    ProfileComponent,
    ChequeComponent,
    LoanComponent,
    ViewsavingComponent,
    HomeComponent,
    AloginComponent,
    UseraccountComponent,
    ChequebookComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
